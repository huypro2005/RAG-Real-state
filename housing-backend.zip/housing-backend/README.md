# housing-backend

Database cho chatbot tư vấn bất động sản TP.HCM.
PostgreSQL + PostGIS + pgvector · SQLAlchemy 2.0 (async) · Alembic · FastAPI.

**Mọi bảng nằm trong schema mặc định `public`**, nên SQL và model không cần ghi tên schema.
5 schema cũ (`admin`, `amenities`, `listing`, `ml`, `rag`) đã bỏ. Tên bảng và cột giữ nguyên.

## Cấu trúc thư mục

```
housing-backend/
├── db/                         # SQL gốc: nguồn chuẩn của cấu trúc DB
│   ├── schema.sql              #   tạo toàn bộ bảng, index, view (DB mới)
│   ├── functions.sql           #   nearby(), refresh_spatial_features()
│   └── move_to_public.sql      #   chuyển DB cũ (5 schema) sang public
├── scripts/
│   ├── fix_backup.ps1          # sửa file backup cũ -> backup mới chỉ dùng public (Windows)
│   └── fix_backup.sh           #   bản bash
├── app/
│   ├── db/
│   │   ├── base.py             # Base (bảng), ViewBase (view), quy ước tên, map kiểu
│   │   ├── session.py          # kết nối async + get_session cho FastAPI
│   │   └── models/
│   │       ├── admin_unit.py   #   Unit, WardTransition
│   │       ├── district.py     #   DistrictLabel, DistrictLink
│   │       ├── poi.py          #   PoiSchool, PoiHospital, PoiMarket
│   │       ├── listing.py      #   Listing, ListingSpatialFeatures, ListingEmbedding
│   │       └── views.py        #   HousingPoi, PoiDistrictFeature (chỉ đọc)
│   ├── repositories/           # hàm truy vấn DB
│   ├── schemas/                # Pydantic cho request/response API
│   ├── api/                    # router FastAPI
│   └── main.py
└── migrations/                 # Alembic; 0001_baseline chạy db/schema.sql
```

## Bảng và model

| Bảng / view | Model | Ý nghĩa |
|---|---|---|
| `unit` | `Unit` | Tỉnh / quận / phường, cả bộ cũ (`legacy_2025`) và mới (`from_2025`) |
| `ward_transition` | `WardTransition` | Phường cũ → phường mới |
| `district_label` | `DistrictLabel` | Nhãn quận 0..23 theo model version |
| `district_link` | `DistrictLink` | Quận trong `unit` → nhãn |
| `poi_schools` / `poi_hospitals` / `poi_markets` | `PoiSchool` / `PoiHospital` / `PoiMarket` | Tiện ích; chung 18 cột (`PoiColumns`) |
| `listings` | `Listing` | Tin đăng |
| `listing_spatial_features` | `ListingSpatialFeatures` | Số POI 1 km/3 km + POI gần nhất |
| `listing_embeddings` | `ListingEmbedding` | Vector 1024 chiều (bge-m3) |
| `housing_poi` (view) | `HousingPoi` | 3 bảng POI gộp lại |
| `poi_district_features` (view) | `PoiDistrictFeature` | POI + nhãn quận (`hcm_24_user_v1`) |

Cách đọc một model:

```python
class Listing(Base):
    __tablename__ = "listings"
    title: Mapped[str]                 # text NOT NULL
    description: Mapped[str | None]    # text, cho phép NULL
    price: Mapped[float]               # double precision NOT NULL
    geom: Mapped[Any | None] = mapped_column(GEOGRAPHY_POINT, Computed(...))  # Postgres tự tính
```

Cột có `Computed(...)` (`geom`, `student_count`, `ownership`...) do Postgres tự tính từ
`latitude/longitude` hoặc `raw_record`. **Không gán giá trị** cho các cột này khi insert.

## Sửa file backup cũ (5 schema → public)

File backup bạn gửi lên bị hỏng khi upload: file nhị phân bị đổi thành text, mất toàn bộ byte `00`,
nên **không khôi phục được dữ liệu** từ bản đó. Hãy chạy script trên máy có file gốc.
Script không sửa file gốc mà tạo file mới.

```powershell
# Windows PowerShell, đứng ở thư mục gốc project
$env:PGPASSWORD = "mat_khau_postgres"
.\scripts\fix_backup.ps1 -Backup "D:\duong\dan\data_ultilities.sql" -OutDir ".\backup"
# Nếu báo không tìm thấy pg_restore, thêm:  -PgBin "C:\Program Files\PostgreSQL\18\bin"
```

Kết quả gồm `housing_public.dump` (định dạng custom) và `housing_public.sql` (text).

**Máy chưa cài pgvector:** script tự phát hiện, bỏ extension `vector` và bảng `listing_embeddings`
(bảng duy nhất dùng kiểu `vector`), các bảng còn lại restore bình thường. File mới khi đó không có
bảng embedding; file backup gốc vẫn còn đủ. Cài pgvector rồi chạy lại script là có bản đầy đủ.
Nếu đã `alembic stamp 0001` trên DB thiếu bảng này, `alembic revision --autogenerate` sẽ muốn tạo lại
`listing_embeddings`: bỏ lệnh đó khỏi file migration cho tới khi cài pgvector.
Khi cần gửi file lên chat, **nén thành .zip trước**, để file không bị đổi định dạng như lần này.

Nếu muốn chuyển thẳng DB đang chạy (không qua file backup):

```bash
cd db
psql -d housing -1 -v ON_ERROR_STOP=1 -f move_to_public.sql
```

Script chạy trong 1 transaction. Nếu public đã có bảng trùng tên hoặc còn sót object, nó báo lỗi và không đổi gì.

## Chạy project

```bash
cp .env.example .env
docker compose up -d db
pip install -e ".[dev]"
```

Sau đó chọn một trong hai cách:

- **DB trống:** `alembic upgrade head`. Lệnh này tạo toàn bộ cấu trúc từ `db/schema.sql`.
- **DB đã restore từ `housing_public.dump`:** `alembic stamp 0001`. Lệnh này chỉ đánh dấu baseline vì bảng đã có sẵn.

Rồi chạy `uvicorn app.main:app --reload` và mở http://127.0.0.1:8000/docs.

## Khi cấu trúc DB thay đổi

1. Sửa model trong `app/db/models/`.
2. `alembic revision --autogenerate --rev-id 0002 -m "them cot xyz"`
3. **Đọc lại file migration vừa sinh.** Autogenerate không nhận ra các trường hợp sau:
   - Đổi tên cột: nó sinh lệnh xóa cột rồi thêm cột mới, làm mất dữ liệu. Sửa thành `op.alter_column(..., new_column_name=...)`.
   - Thay đổi view, function hoặc biểu thức `Computed`: phải tự viết `op.execute("CREATE OR REPLACE ...")`.
4. `alembic upgrade head`
5. Cập nhật `db/schema.sql` / `db/functions.sql` cho khớp, để người dựng DB mới có bản mới nhất.

## Gọi function từ Python

```python
await session.execute(select(func.refresh_spatial_features()))
rows = await PoiRepository(session).nearby(106.70, 10.77, radius_m=1000, poi_type="truong_hoc")
```
