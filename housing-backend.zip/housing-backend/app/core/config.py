from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+asyncpg://housing:housing@localhost:5432/housing"
    db_echo: bool = False
    db_pool_size: int = 10
    db_max_overflow: int = 20

    district_model_version: str = "hcm_24_user_v1"
    embedding_model_name: str = "BAAI/bge-m3"
    embedding_dim: int = 1024

    @property
    def sync_database_url(self) -> str:
        """URL cho Alembic / script import (driver sync psycopg)."""
        return self.database_url.replace("+asyncpg", "+psycopg")


@lru_cache
def get_settings() -> Settings:
    return Settings()
