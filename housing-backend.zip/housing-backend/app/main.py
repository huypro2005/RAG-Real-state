from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import text

from app.api.deps import SessionDep
from app.api.v1.routes import router as v1_router
from app.db.session import engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    # KHÔNG gọi create_all ở đây: schema do Alembic quản lý (alembic upgrade head)
    yield
    await engine.dispose()


app = FastAPI(title="Housing API", version="0.1.0", lifespan=lifespan)
app.include_router(v1_router, prefix="/api/v1")


@app.get("/health", tags=["system"])
async def health(session: SessionDep):
    await session.execute(text("SELECT 1"))
    return {"status": "ok"}
