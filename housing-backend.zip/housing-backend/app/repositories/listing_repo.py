from collections.abc import Iterable
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.db.models import Listing, ListingEmbedding

# Cột không được ghi khi UPSERT: khóa chính, cột GENERATED, thời điểm nạp lần đầu
_NOT_UPDATABLE = {"listing_id", "geom", "first_loaded_at"}


class ListingRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, listing_id: str) -> Listing | None:
        stmt = (
            select(Listing)
            .options(selectinload(Listing.spatial_features))
            .where(Listing.listing_id == listing_id)
        )
        return (await self.session.execute(stmt)).scalar_one_or_none()

    async def upsert_many(self, rows: Iterable[dict[str, Any]]) -> int:
        """UPSERT theo listing_id. Không commit — caller quyết định transaction."""
        rows = list(rows)
        if not rows:
            return 0
        stmt = insert(Listing).values(rows)
        update_cols = {
            c.name: stmt.excluded[c.name]
            for c in Listing.__table__.columns
            if c.name not in _NOT_UPDATABLE and c.computed is None
        }
        update_cols["updated_at"] = func.now()
        stmt = stmt.on_conflict_do_update(index_elements=["listing_id"], set_=update_cols)
        await self.session.execute(stmt)
        return len(rows)

    async def refresh_spatial_features(self) -> int:
        result = await self.session.execute(select(func.refresh_spatial_features()))
        return int(result.scalar_one())

    async def search_by_embedding(
        self, query_vector: list[float], limit: int = 10, transaction_type: str | None = None
    ) -> list[tuple[Listing, float]]:
        """Tìm tin gần nghĩa nhất theo cosine distance.

        DB hiện chưa có index vector nên Postgres quét toàn bảng; khi dữ liệu lớn
        thêm index HNSW bằng một migration mới.
        """
        distance = ListingEmbedding.embedding.cosine_distance(query_vector).label("distance")
        stmt = (
            select(Listing, distance)
            .join(ListingEmbedding, ListingEmbedding.listing_id == Listing.listing_id)
            .order_by(distance)
            .limit(limit)
        )
        if transaction_type:
            stmt = stmt.where(Listing.transaction_type == transaction_type)
        return [(row[0], row[1]) for row in await self.session.execute(stmt)]
