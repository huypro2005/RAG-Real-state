from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_session
from app.repositories.listing_repo import ListingRepository
from app.repositories.poi_repo import PoiRepository

SessionDep = Annotated[AsyncSession, Depends(get_session)]


def get_listing_repo(session: SessionDep) -> ListingRepository:
    return ListingRepository(session)


def get_poi_repo(session: SessionDep) -> PoiRepository:
    return PoiRepository(session)


ListingRepoDep = Annotated[ListingRepository, Depends(get_listing_repo)]
PoiRepoDep = Annotated[PoiRepository, Depends(get_poi_repo)]
