from fastapi import APIRouter, HTTPException, Query

from app.api.deps import ListingRepoDep, PoiRepoDep
from app.schemas.listing import ListingOut
from app.schemas.poi import NearbyPoiOut, PoiType

router = APIRouter()


@router.get("/listings/{listing_id}", response_model=ListingOut, tags=["listings"])
async def get_listing(listing_id: str, repo: ListingRepoDep):
    listing = await repo.get(listing_id)
    if listing is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy tin")
    return listing


@router.get("/pois/nearby", response_model=list[NearbyPoiOut], tags=["pois"])
async def get_nearby_pois(
    repo: PoiRepoDep,
    lat: float = Query(ge=-90, le=90),
    lon: float = Query(ge=-180, le=180),
    radius_m: float = Query(1000, gt=0, le=10_000),
    poi_type: PoiType | None = None,
    limit: int = Query(50, ge=1, le=200),
):
    return await repo.nearby(lon, lat, radius_m, poi_type, limit)
