"""Base class cho mọi model.

Mọi bảng nằm trong schema mặc định (public) nên model không khai báo schema.

NAMING_CONVENTION đặt tên constraint giống hệt cách Postgres tự đặt
(unit_pkey, unit_parent_id_fkey, ...). Nhờ vậy model khớp với DB đang có
và `alembic revision --autogenerate` không sinh ra thay đổi thừa.
"""

from datetime import datetime

from sqlalchemy import DateTime, Double, MetaData, Text
from sqlalchemy.orm import DeclarativeBase

NAMING_CONVENTION = {
    "pk": "%(table_name)s_pkey",
    "uq": "%(table_name)s_%(column_0_N_name)s_key",
    "fk": "%(table_name)s_%(column_0_N_name)s_fkey",
    # CHECK và INDEX đặt tên trực tiếp trong từng model
}

# Kiểu Python -> kiểu cột Postgres. Nhờ bảng này, chỉ cần viết
# `name: Mapped[str]` là ra cột text NOT NULL, `Mapped[str | None]` là text NULL.
TYPE_MAP = {
    str: Text,                         # mặc định SQLAlchemy dùng VARCHAR, DB dùng text
    float: Double,                     # double precision
    datetime: DateTime(timezone=True), # timestamp with time zone
}


class Base(DeclarativeBase):
    """Base cho BẢNG. Alembic chỉ quản lý những gì kế thừa class này."""

    metadata = MetaData(naming_convention=NAMING_CONVENTION)
    type_annotation_map = TYPE_MAP


class ViewBase(DeclarativeBase):
    """Base cho VIEW (chỉ đọc).

    Dùng metadata riêng nên create_all() và Alembic không đụng tới view.
    View được tạo bằng SQL trong db/schema.sql.
    """

    type_annotation_map = TYPE_MAP
