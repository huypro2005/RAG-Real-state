"""Model CHỈ ĐỌC cho 2 view (định nghĩa SQL nằm trong db/schema.sql)."""

from datetime import datetime
from typing import Any

from sqlalchemy import BigInteger, SmallInteger
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import ViewBase
from app.db.models.poi import GEOGRAPHY_POINT


class HousingPoi(ViewBase):
    """View housing_poi = poi_schools + poi_hospitals + poi_markets."""

    __tablename__ = "housing_poi"

    # View không có khóa chính; (poi_id, poi_type) là duy nhất nên dùng làm khóa cho ORM
    poi_id: Mapped[str] = mapped_column(primary_key=True)
    poi_type: Mapped[str] = mapped_column(primary_key=True)
    poi_subtype: Mapped[str | None]
    name: Mapped[str]
    address_old: Mapped[str | None]
    address_new: Mapped[str | None]
    old_province_id: Mapped[int | None] = mapped_column(BigInteger)
    old_district_id: Mapped[int | None] = mapped_column(BigInteger)
    old_ward_id: Mapped[int | None] = mapped_column(BigInteger)
    new_province_id: Mapped[int | None] = mapped_column(BigInteger)
    new_ward_id: Mapped[int | None] = mapped_column(BigInteger)
    latitude: Mapped[float | None]
    longitude: Mapped[float | None]
    mapping_status: Mapped[dict[str, Any]] = mapped_column(JSONB)
    source_file: Mapped[str]
    source_sha256: Mapped[str]
    raw_record: Mapped[dict[str, Any]] = mapped_column(JSONB)
    imported_at: Mapped[datetime]
    geom: Mapped[Any | None] = mapped_column(GEOGRAPHY_POINT)


class PoiDistrictFeature(ViewBase):
    """View poi_district_features: mỗi POI kèm nhãn quận của model 'hcm_24_user_v1'.

    label_status: 'matched_district_name' | 'ambiguous_pre_2021_district' | 'unresolved'
    """

    __tablename__ = "poi_district_features"

    poi_id: Mapped[str] = mapped_column(primary_key=True)
    poi_type: Mapped[str] = mapped_column(primary_key=True)
    name: Mapped[str]
    old_district_id: Mapped[int | None] = mapped_column(BigInteger)
    district_label: Mapped[int | None] = mapped_column(SmallInteger)
    label_status: Mapped[str]
    mapping_status: Mapped[dict[str, Any]] = mapped_column(JSONB)
    old_address_confidence: Mapped[str | None]
    geocode_confidence: Mapped[str | None]
    manual_review_required: Mapped[str | None]
