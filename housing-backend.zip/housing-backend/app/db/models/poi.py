"""Tiện ích (POI): poi_schools, poi_hospitals, poi_markets.

3 bảng có chung 18 cột + geom, nên gom vào class PoiColumns.
Mỗi bảng chỉ khai báo thêm: tên bảng, CHECK/INDEX, và các cột riêng.

Cột GENERATED (Computed) do Postgres tự tính. Khi INSERT/UPDATE
không được gán giá trị cho các cột này.
"""

from datetime import datetime
from typing import Any

from geoalchemy2 import Geography
from sqlalchemy import BigInteger, CheckConstraint, Computed, ForeignKey, Index, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base

# geography(Point, 4326): kinh độ/vĩ độ, ST_Distance trả về mét.
# spatial_index=False vì index GiST đã khai báo tường minh bên dưới.
GEOGRAPHY_POINT = Geography(geometry_type="POINT", srid=4326, spatial_index=False)

# geom tự tính từ (longitude, latitude)
POI_GEOM_SQL = (
    "CASE WHEN longitude IS NOT NULL AND latitude IS NOT NULL "
    "THEN st_setsrid(st_makepoint(longitude, latitude), 4326)::geography "
    "ELSE NULL::geography END"
)


def from_raw(key: str, cast: str | None = None) -> Computed:
    """Cột tự tính = raw_record ->> key (chuỗi rỗng thành NULL), có thể ép kiểu."""
    expr = f"NULLIF(raw_record ->> '{key}', '')"
    if cast:
        expr = f"({expr})::{cast}"
    return Computed(expr, persisted=True)


class PoiColumns:
    """Các cột chung của 3 bảng POI (không phải bảng, chỉ để kế thừa)."""

    poi_id: Mapped[str] = mapped_column(primary_key=True)
    poi_type: Mapped[str]
    poi_subtype: Mapped[str | None]
    name: Mapped[str]
    address_old: Mapped[str | None]
    address_new: Mapped[str | None]

    # Liên kết tới bảng unit (tỉnh/quận/phường cũ và mới)
    old_province_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))
    old_district_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))
    old_ward_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))
    new_province_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))
    new_ward_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))

    latitude: Mapped[float | None]
    longitude: Mapped[float | None]
    mapping_status: Mapped[dict[str, Any]] = mapped_column(JSONB)
    source_file: Mapped[str]
    source_sha256: Mapped[str]
    raw_record: Mapped[dict[str, Any]] = mapped_column(JSONB)
    imported_at: Mapped[datetime] = mapped_column(server_default=func.now())

    geom: Mapped[Any | None] = mapped_column(GEOGRAPHY_POINT, Computed(POI_GEOM_SQL, persisted=True))


def poi_table_args(table: str, poi_type: str) -> tuple:
    """CHECK + INDEX giống nhau cho cả 3 bảng, chỉ khác tên bảng và poi_type."""
    return (
        CheckConstraint(f"poi_type = '{poi_type}'", name=f"{table}_poi_type_check"),
        CheckConstraint("(latitude IS NULL) = (longitude IS NULL)", name=f"{table}_check"),
        CheckConstraint("latitude >= -90 AND latitude <= 90", name=f"{table}_latitude_check"),
        CheckConstraint("longitude >= -180 AND longitude <= 180", name=f"{table}_longitude_check"),
        Index(f"{table}_geom_gist", "geom", postgresql_using="gist"),
        Index(f"{table}_old_district_idx", "old_district_id"),
        Index(f"{table}_new_ward_idx", "new_ward_id"),
    )


class PoiSchool(PoiColumns, Base):
    """Trường học — poi_type = 'truong_hoc'."""

    __tablename__ = "poi_schools"
    __table_args__ = poi_table_args("poi_schools", "truong_hoc")

    campus_name: Mapped[str | None] = mapped_column(from_raw("campus_name"))
    school_level_codes: Mapped[str | None] = mapped_column(from_raw("school_level_codes"))
    ownership: Mapped[str | None] = mapped_column(from_raw("ownership"))
    student_count: Mapped[int | None] = mapped_column(from_raw("student_count", "integer"))
    old_address_confidence: Mapped[str | None] = mapped_column(from_raw("old_address_confidence"))


class PoiHospital(PoiColumns, Base):
    """Bệnh viện — poi_type = 'benh_vien'."""

    __tablename__ = "poi_hospitals"
    __table_args__ = poi_table_args("poi_hospitals", "benh_vien")

    ownership: Mapped[str | None] = mapped_column(from_raw("ownership"))


class PoiMarket(PoiColumns, Base):
    """Chợ — poi_type = 'cho'."""

    __tablename__ = "poi_markets"
    __table_args__ = poi_table_args("poi_markets", "cho")

    manual_review_required: Mapped[bool | None] = mapped_column(
        from_raw("manual_review_required", "boolean")
    )
