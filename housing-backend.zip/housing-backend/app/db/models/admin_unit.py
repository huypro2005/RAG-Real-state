"""Đơn vị hành chính TP.HCM: bảng unit và ward_transition."""

from typing import Any

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, Identity, Index, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class Unit(Base):
    """Một dòng = một tỉnh, quận hoặc phường.

    - version: 'legacy_2025' (bộ cũ) hoặc 'from_2025' (bộ mới, không còn cấp quận)
    - level:   'province' | 'district' | 'ward'
    - parent_id: phường -> quận -> tỉnh. Chỉ tỉnh có parent_id = NULL.
    """

    __tablename__ = "unit"
    __table_args__ = (
        UniqueConstraint("version", "level", "code"),
        CheckConstraint("version IN ('legacy_2025', 'from_2025')", name="unit_version_check"),
        CheckConstraint("level IN ('province', 'district', 'ward')", name="unit_level_check"),
        CheckConstraint("NOT (version = 'from_2025' AND level = 'district')", name="unit_check"),
        CheckConstraint("(level = 'province') = (parent_id IS NULL)", name="unit_check1"),
        Index("unit_parent_idx", "parent_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, Identity(always=True), primary_key=True)
    version: Mapped[str]
    level: Mapped[str]
    code: Mapped[str]
    name: Mapped[str]
    parent_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("unit.id"))
    source_file: Mapped[str]
    raw_record: Mapped[dict[str, Any]] = mapped_column(JSONB)

    parent: Mapped["Unit | None"] = relationship(remote_side=[id], back_populates="children")
    children: Mapped[list["Unit"]] = relationship(back_populates="parent")

    def __repr__(self) -> str:
        return f"<Unit {self.version}/{self.level} {self.code} {self.name}>"


class WardTransition(Base):
    """Phường cũ -> phường mới sau sáp nhập (nhiều - nhiều)."""

    __tablename__ = "ward_transition"

    old_ward_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("unit.id"), primary_key=True)
    new_ward_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("unit.id"), primary_key=True)
    source_file: Mapped[str]
    raw_record: Mapped[dict[str, Any]] = mapped_column(JSONB)

    old_ward: Mapped[Unit] = relationship(foreign_keys=[old_ward_id])
    new_ward: Mapped[Unit] = relationship(foreign_keys=[new_ward_id])
