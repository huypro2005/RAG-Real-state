"""Nhãn quận (0..23) mà model dự đoán giá dùng: district_label và district_link."""

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, ForeignKeyConstraint, SmallInteger, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.db.models.admin_unit import Unit


class DistrictLabel(Base):
    """Bảng tra nhãn: (model_version, label) -> tên quận."""

    __tablename__ = "district_label"
    __table_args__ = (
        UniqueConstraint("model_version", "district_name"),
        CheckConstraint("label >= 0 AND label <= 23", name="district_label_label_check"),
    )

    model_version: Mapped[str] = mapped_column(primary_key=True)
    label: Mapped[int] = mapped_column(SmallInteger, primary_key=True)
    district_name: Mapped[str]


class DistrictLink(Base):
    """Quận trong bảng unit -> nhãn của model."""

    __tablename__ = "district_link"
    __table_args__ = (
        # FK 2 cột: (model_version, label) phải có trong district_label
        ForeignKeyConstraint(
            ["model_version", "label"],
            ["district_label.model_version", "district_label.label"],
        ),
    )

    admin_district_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("unit.id"), primary_key=True
    )
    model_version: Mapped[str] = mapped_column(primary_key=True)
    label: Mapped[int] = mapped_column(SmallInteger)
    evidence: Mapped[str]

    district: Mapped[Unit] = relationship()
    district_label: Mapped[DistrictLabel] = relationship()
