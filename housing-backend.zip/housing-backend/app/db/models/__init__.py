"""Tất cả model. Import từ đây:  from app.db.models import Listing, Unit, ...

File này import mọi model để Base.metadata có đủ bảng (Alembic cần).

    admin_unit.py  -> unit, ward_transition
    district.py    -> district_label, district_link
    poi.py         -> poi_schools, poi_hospitals, poi_markets
    listing.py     -> listings, listing_spatial_features, listing_embeddings
    views.py       -> housing_poi, poi_district_features (chỉ đọc)
"""

from app.db.models.admin_unit import Unit, WardTransition
from app.db.models.district import DistrictLabel, DistrictLink
from app.db.models.listing import Listing, ListingEmbedding, ListingSpatialFeatures
from app.db.models.poi import PoiHospital, PoiMarket, PoiSchool
from app.db.models.views import HousingPoi, PoiDistrictFeature

__all__ = [
    "Unit",
    "WardTransition",
    "DistrictLabel",
    "DistrictLink",
    "PoiSchool",
    "PoiHospital",
    "PoiMarket",
    "Listing",
    "ListingSpatialFeatures",
    "ListingEmbedding",
    "HousingPoi",
    "PoiDistrictFeature",
]
