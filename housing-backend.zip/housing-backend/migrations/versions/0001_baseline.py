"""baseline: toàn bộ schema hiện tại (db/schema.sql + db/functions.sql)

Revision ID: 0001
Revises:
Create Date: 2026-10-08

- DB MỚI (trống):            alembic upgrade head      -> chạy schema.sql
- DB ĐÃ CÓ bảng và dữ liệu:  alembic stamp 0001        -> chỉ ghi nhận, không chạy gì
Các thay đổi sau này viết thành migration mới (0002, 0003...), KHÔNG sửa schema.sql
cho DB đang chạy.
"""

from pathlib import Path

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

DB_DIR = Path(__file__).resolve().parents[2] / "db"


def _read_sql(name: str) -> str:
    """Đọc file .sql, thay dòng `\\ir file.sql` (lệnh riêng của psql) bằng nội dung file đó."""
    lines = []
    for line in (DB_DIR / name).read_text(encoding="utf-8").splitlines():
        if line.startswith("\\ir "):
            lines.append(_read_sql(line.split(maxsplit=1)[1].strip()))
        else:
            lines.append(line)
    return "\n".join(lines)


def upgrade() -> None:
    # exec_driver_sql: gửi nguyên văn cho Postgres, SQLAlchemy không phân tích dấu ':'
    op.get_bind().exec_driver_sql(_read_sql("schema.sql"))


def downgrade() -> None:
    op.get_bind().exec_driver_sql(
        """
        DROP FUNCTION IF EXISTS refresh_spatial_features();
        DROP FUNCTION IF EXISTS nearby(double precision, double precision, double precision, text);
        DROP VIEW IF EXISTS poi_district_features;
        DROP VIEW IF EXISTS housing_poi;
        DROP TABLE IF EXISTS listing_embeddings, listing_spatial_features, listings,
                             poi_markets, poi_hospitals, poi_schools,
                             district_link, district_label, ward_transition, unit;
        """
    )
